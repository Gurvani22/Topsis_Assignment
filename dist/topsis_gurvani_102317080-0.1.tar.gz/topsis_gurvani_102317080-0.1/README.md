# TOPSIS Package

This package implements the TOPSIS ranking method.

## Usage

topsis data.xlsx "1,1,1,1,1" "+,+,-,+,+" output.csv
